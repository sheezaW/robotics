#include "image.h"
#include <iostream>
#include <fstream>
using namespace std;
colour::colour()
        : r(0),g(0),b(0)
{

}
colour::colour(float r,float g, float b)
        :r(r),g(g),b(b)
{

}
image::image(int width,int height)
        :m_width(width),m_height(height),m_colours(vector<colour>(width*height))
{

}
image::~image()
{

}
colour image::Getcolour(int x,int y)const
{
    return m_colours[y*m_width+x];
}
void image::Setcolour(const colour& colour,int x , int y)
{
    m_colours[y* m_width +x].r = colour.r;
    m_colours[y* m_width +x].g = colour.g;
    m_colours[y* m_width +x].b = colour.b;

}
void image::read(const char* path)
{
    ifstream f;
    f.open(path,ios::in|ios::binary);
    if(!f.is_open())
        cout<<"file not open"<<endl;
    const int fileheadersize=14;
    const int infoheadersize=40;
    unsigned char fileheader[fileheadersize];
    f.read( reinterpret_cast<char*>( fileheader), fileheadersize);
    if(fileheader[0]!='B'|| fileheader[1]!='M')
    {
        cout<<"this is not a bmp file"<<endl;

    }
     unsigned char infoheader[infoheadersize];
    f.read( reinterpret_cast<char*>( infoheader), infoheadersize);
    int filesize= fileheader[2]+ (fileheader[3]<<8)+(fileheader[4]<<16)+(fileheader[5]<<24);
    m_width= infoheader[4]+ (infoheader[5]<<8)+(infoheader[6]<<16)+(infoheader[7]<<24);
    m_height=  infoheader[4]+ (infoheader[9]<<8)+(infoheader[10]<<16)+(infoheader[11]<<24);
    m_colours.resize(m_width*m_height);
    const int padding= ((4-(m_width*3)%4)%4);
     for (int y=0; y<m_height;y++)
    {
        for(int x=0;x<m_width;x++)
        {
          unsigned char colour[3];
          f.read(reinterpret_cast<char*>(colour),3);
          m_colours[y*m_width +x].r= static_cast<float>(colour[2])/255.0f;
          m_colours[y*m_width +x].g= static_cast<float>(colour[1])/255.0f;
          m_colours[y*m_width +x].b= static_cast<float>(colour[0])/255.0f;
        }
        f.ignore(padding);
    }
    f.close();
    cout<<"file read"<<endl;

    }
void image::Export(const char* path)const
{
    ofstream f;
    f.open(path,ios::out|ios::binary);
    if(!f.is_open())
        cout<<"file not open"<<endl;
    unsigned char bmpPad[3]={0,0,0};
    const int padding= ((4-(m_width*3)%4)%4);
    const int fileheadersize=14;
    const int infoheadersize=40;
    const int filesize= fileheadersize+infoheadersize+ m_width*m_height*3 + padding*m_width;
    unsigned char fileheader[fileheadersize];
    fileheader[0]= 'B';fileheader[1]= 'M';
    fileheader[2]= filesize;
    fileheader[3]= filesize>>8;
    fileheader[4]= filesize>>16;
    fileheader[5]= filesize>>24;
    fileheader[6]=0; fileheader[7]=0; fileheader[8]=0; fileheader[9]=0;
    fileheader[10]=fileheadersize+infoheadersize;
    fileheader[11]=0;fileheader[12]=0;fileheader[13]=0;
    unsigned char infoheader[infoheadersize];
    infoheader[0]= infoheadersize;
    infoheader[1]=0;infoheader[2]=0;infoheader[3]=0;
    infoheader[4]=m_width;
    infoheader[5]=m_width>>8;
    infoheader[6]=m_width>>16;
    infoheader[7]=m_width>>24;
    infoheader[8]= m_height;
    infoheader[9]= m_height>>8;
    infoheader[10]= m_height>>16;
    infoheader[11]= m_height>>24;
    infoheader[12]= 1;
    infoheader[13]=0;
    infoheader[14]=24;
    int i=15;
    while (i>14 && i<39)
    {
        infoheader[i]=0;
        i++;
    }
    f.write(reinterpret_cast<char*>(fileheader),fileheadersize);
    f.write(reinterpret_cast<char*>(infoheader),infoheadersize);
    for (int y=0; y<m_height;y++)
    {
        for(int x=0;x<m_width;x++)
        {
            unsigned char  r = Getcolour(x,y).r*255.0f;
            unsigned char  g = Getcolour(x,y).g*255.0f;
            unsigned char  b = Getcolour(x,y).b*255.0f;

            unsigned char colour[]= {b,g,r};
            f.write(reinterpret_cast<char*>(colour),3);
        }
        f.write(reinterpret_cast<char*>(bmpPad),padding);
    }
    f.close();
    cout<<"file created"<<endl;
}


