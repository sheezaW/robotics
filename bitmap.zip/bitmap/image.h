
#include <vector>

using namespace std;

struct colour
{
    float r,g,b;
   colour ();
   colour( float r , float g, float b);

};
class image
{
   public:
       image( int width, int height);
       ~image();
       colour Getcolour(int x,int y)const;
       void Setcolour(const  colour& colour,int x,int y);
       void read(const char* path);
       void Export(const char* path ) const;
   private:
    int m_width;
    int m_height;
    vector<colour> m_colours;
};
