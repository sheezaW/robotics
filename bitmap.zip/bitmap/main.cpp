#include <iostream>
#include "image.h"
using namespace std;
int main()
{

   const int width= 300;
   const int height= 400;
   image image(width,height);
   for (int y=0; y<height; y++)
    {
        for(int x=0; x<width; x++)
        {
            image.Setcolour(colour((float)x / (float)width,1.0f -((float)x/(float)width),(float)y/(float)height),x,y );
        }
    }
    image.Export("try.bmp");
    image.read("sheeza.bmp");
    image.read("try.bmp");

}
